# Code of Conduct #

This file will be expanded in the future, but for now, just try to keep
things pretty simple. Be nice when communicating between different collaborators
and contributors. Don't spam the administrators of **Quick Note** with phony
submissions. We are here to write code and have fun, and maybe learn something
along the way.

