#!/usr/bin/env bash

brew tap scamacho23/quicknote
